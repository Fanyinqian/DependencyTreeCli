import * as React from 'react';
import './index.scss'

interface AssitProps {
  
}
 
interface AssitState {
  
}
 
class Assit extends React.Component<AssitProps, AssitState> {
  // constructor(props: AssitProps) {
  //   super(props);
  //   this.state = { :  };
  // }
  render() { 
    return ( 
      <>
        <div className="assit">
          <div className="assitCon">
            
          </div>
        </div>
      </>
     );
  }
}
 
export default Assit;